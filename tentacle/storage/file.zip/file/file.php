<?php
    echo "I'm sorry Dave, I'm afraid I can't do that.";
?>